package com.example.metropass

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
